from django.contrib import admin
from .models import ShippingTable
# Register your models here.
admin.site.register(ShippingTable)